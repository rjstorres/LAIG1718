/**
 * Base Animation class
 * @constructor
**/

function Animation(scene,args){
}


Animation.prototype.animate = function(){
}

Animation.prototype.restartTime = function(){

}
